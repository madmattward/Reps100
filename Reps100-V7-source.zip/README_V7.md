# Reps100 V7

V7 is based on the tested V6 source and implements the requested refinement pass.

Highlights:
- workout order is set-first: set 1 cycles through every exercise, then set 2, and so on
- keyboard-aware weight entry with larger routine exercise cards and safer multi-line titles
- dumbbell entries represent one dumbbell; calorie calculations use the pair (2x) for dumbbell exercises
- kettlebell exercises accept a weight entry without automatic doubling
- completed-routine calorie chart uses a 0–1000 kcal scale
- segmented mechanical-work + resting-MET calorie estimate
- expanded equipment filters: Bodyweight, Barbell, Dumbbell, Cable, Machine and Kettlebell
- requested exercise removals, reclassifications, additions and renames
- detailed per-exercise instructions for the requested movement list
- photorealistic male/female body-composition guide selected by biological sex
- full-body measurement artwork uses fit-to-frame sizing and dashed height/waist/hip guides

Calorie and body-composition values are estimates and screening aids, not medical measurements.
