package __PACKAGE__;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.*;

public class MainActivity extends Activity {
  final int BG=Color.rgb(10,13,16), CARD=Color.rgb(23,28,33), CARD2=Color.rgb(30,36,42), TEXT=Color.rgb(245,247,250), MUTED=Color.rgb(160,170,180), BLUE=Color.rgb(38,120,235), GREEN=Color.rgb(65,185,105), RED=Color.rgb(235,85,85);
  LinearLayout root, body; ArrayDeque<View> stack=new ArrayDeque<>(); String current="home";
  ArrayList<ExerciseData.Exercise> routine=new ArrayList<>(); int[] setReps={20,20,20,20,20}; int currentSet=0;
  SharedPreferences prefs;

  @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(Color.BLACK); prefs=getSharedPreferences("reps100",0); if(Build.VERSION.SDK_INT>=33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0, this::goBack); showHome(false);}
  @Override public void onBackPressed(){goBack();}
  void goBack(){ if(!stack.isEmpty()){ root.removeAllViews(); root.add(stack.pop()); current="back"; } else super.onBackPressed(); }
  TextView tv(String s,float size,int color){TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(18,8,18,8); return t;}
  LinearLayout col(){LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(16,12,16,18); l.setBackgroundColor(BG); return l;}
  ScrollView scroll(View v){ScrollView s=new ScrollView(this); s.setFillViewport(true); s.addView(v); return s;}
  GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
  Button button(String label,int color){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);b.setBackground(bg(color,22));b.setPadding(14,4,14,4);return b;}
  void show(View v, boolean push){ if(push && root!=null && root.getChildCount()>0) stack.push(root.getChildAt(0)); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.addView(v,new LinearLayout.LayoutParams(-1,-1));setContentView(root); }
  LinearLayout page(String title){ LinearLayout p=col(); LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(0,0,0,6); Button back=button("‹",CARD2); back.setTextSize(28); back.setContentDescription("Back"); back.setOnClickListener(v->goBack());bar.addView(back,new LinearLayout.LayoutParams(56,52)); TextView h=tv(title,22,TEXT);h.setTypeface(null,1);bar.addView(h,new LinearLayout.LayoutParams(0,52,1));p.addView(bar);return p; }
  void showHome(boolean push){
    stack.clear();
    LinearLayout p=col(); TextView brand=tv("REPS100",32,TEXT);brand.setTypeface(null,1);brand.setPadding(8,16,8,2);p.addView(brand);TextView sub=tv("100 reps. One exercise at a time.",15,BLUE);p.addView(sub);
    TextView hi=tv("Welcome back",24,TEXT);hi.setTypeface(null,1);hi.setPadding(8,22,8,10);p.addView(hi);
    addCard(p,"Create Routine","Build a 100-rep workout from your exercise library",BLUE,v->showRoutine(false));
    addCard(p,"Exercise Library","340+ exercises • photos • filters • instructions",Color.rgb(110,80,210),v->showLibrary(false));
    addCard(p,"My Routines","Saved routines and quick starts",GREEN,v->showRoutineList(false));
    addCard(p,"History & Stats","Completed 100-rep workouts",Color.rgb(230,120,35),v->showHistory(false));
    TextView off=tv("OFFLINE FIRST  •  YOUR DATA STAYS ON DEVICE",12,MUTED);off.setGravity(Gravity.CENTER);off.setPadding(8,24,8,8);p.addView(off);
    show(scroll(p),push);
  }
  void addCard(LinearLayout p,String title,String desc,int color,View.OnClickListener l){LinearLayout c=col();c.setPadding(4,4,4,4);c.setBackground(bg(CARD,24));TextView a=tv(title,18,TEXT);a.setTypeface(null,1);c.addView(a);TextView d=tv(desc,13,MUTED);c.addView(d);c.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,92);lp.setMargins(0,7,0,7);p.addView(c,lp);}
  void showLibrary(boolean push){
    LinearLayout p=page("Exercise Library"); EditText search=new EditText(this);search.setHint("Search exercises…");search.setHintTextColor(MUTED);search.setTextColor(TEXT);search.setSingleLine();search.setBackground(bg(CARD,18));p.addView(search,new LinearLayout.LayoutParams(-1,52));
    LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.HORIZONTAL);String[] filters={"All","Chest","Back","Legs","Shoulders","Arms","Core","Cardio"};for(String f:filters){Button b=button(f,CARD2);b.setOnClickListener(v->{search.setTag(f); refreshLibrary(p,search,f);});chips.addView(b,new LinearLayout.LayoutParams(-2,48));}p.addView(chips);
    LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);p.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){refreshLibrary(p,search,(String)search.getTag());}public void afterTextChanged(Editable e){}});search.setTag("All");refreshLibrary(p,search,"All");show(p,push);
  }
  void refreshLibrary(LinearLayout page,EditText search,String filter){
    if(page.getChildCount()<4)return; ScrollView sv=(ScrollView)page.getChildAt(3);LinearLayout list=(LinearLayout)sv.getChildAt(0);list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.US);int shown=0;
    for(ExerciseData.Exercise e:ExerciseData.ALL){boolean fm=filter==null||filter.equals("All")||(filter.equals("Legs")&&(e.muscle.equals("Quads")||e.muscle.equals("Hamstrings")||e.muscle.equals("Glutes")||e.muscle.equals("Calves")))||(filter.equals("Arms")&&(e.muscle.equals("Biceps")||e.muscle.equals("Triceps")))||e.muscle.equals(filter);boolean fq=e.name.toLowerCase(Locale.US).contains(q)||e.muscle.toLowerCase(Locale.US).contains(q)||e.equipment.toLowerCase(Locale.US).contains(q);if(fm&&fq){addExerciseRow(list,e);if(++shown>=80)break;}}
    if(shown==0)list.addView(tv("No exercises found",16,MUTED));
  }
  void addExerciseRow(LinearLayout list,ExerciseData.Exercise e){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(14,10,10,10);r.setBackground(bg(CARD,18));TextView n=tv(e.name,16,TEXT);n.setTypeface(null,1);r.addView(n);r.addView(tv(e.muscle+"  •  "+e.equipment+"  •  "+e.difficulty,12,MUTED));r.setOnClickListener(v->showDetail(e));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,72);lp.setMargins(0,4,0,4);list.addView(r,lp);}
  void showDetail(ExerciseData.Exercise e){
    LinearLayout p=page(e.name); ImageView img=new ImageView(this);int id=getResources().getIdentifier("reps_photo_"+e.photo,"drawable",getPackageName());if(id!=0){img.setImageResource(id);img.setScaleType(ImageView.ScaleType.CENTER_CROP);}img.setBackground(bg(CARD2,18));p.addView(img,new LinearLayout.LayoutParams(-1,210));
    TextView tags=tv(e.muscle.toUpperCase()+"   •   "+e.equipment.toUpperCase()+"   •   "+e.difficulty.toUpperCase(),12,BLUE);tags.setPadding(8,14,8,4);p.addView(tags);
    TextView h=tv("Muscles worked",18,TEXT);h.setTypeface(null,1);p.addView(h);p.addView(tv("Primary: "+e.muscle+"\nMovement: "+e.movement,14,MUTED));
    TextView h2=tv("How to perform",18,TEXT);h2.setTypeface(null,1);p.addView(h2);p.addView(tv("1. Set up with a stable stance and neutral spine.\n2. Control the movement through a comfortable range.\n3. Keep your core braced and breathe steadily.\n4. Return smoothly to the start position.\n\nCommon mistakes: rushing reps, losing posture, and using momentum.",14,MUTED));
    Button add=button("＋  ADD TO ROUTINE",BLUE);add.setOnClickListener(v->{if(!routine.contains(e))routine.add(e);Toast.makeText(this,"Added to routine",Toast.LENGTH_SHORT).show();});p.addView(add,new LinearLayout.LayoutParams(-1,56));show(scroll(p),true);
  }
  void showRoutine(boolean push){
    LinearLayout p=page("Create Routine");TextView total=tv("100 TOTAL REPS",28,TEXT);total.setGravity(Gravity.CENTER);total.setTypeface(null,1);p.addView(total,new LinearLayout.LayoutParams(-1,72));
    TextView info=tv("Exercises: "+routine.size()+"   •   Sets: 1–10   •   Total always equals 100",14,MUTED);p.addView(info);
    LinearLayout list=col();for(ExerciseData.Exercise e:routine){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.addView(tv(e.name,15,TEXT),new LinearLayout.LayoutParams(0,58,1));Button x=button("×",CARD2);x.setOnClickListener(v->{routine.remove(e);showRoutine(false);});row.addView(x,new LinearLayout.LayoutParams(52,50));list.addView(row);}p.addView(scroll(list),new LinearLayout.LayoutParams(-1,0,1));
    Button lib=button("＋  ADD EXERCISE",CARD2);lib.setOnClickListener(v->showLibrary(true));p.addView(lib,new LinearLayout.LayoutParams(-1,56));Button start=button("START 100-REP WORKOUT",BLUE);start.setOnClickListener(v->{if(routine.isEmpty()){Toast.makeText(this,"Add at least one exercise",Toast.LENGTH_SHORT).show();return;}currentSet=0;showWorkout(true);});p.addView(start,new LinearLayout.LayoutParams(-1,58));show(p,push);
  }
  void showWorkout(boolean push){
    LinearLayout p=page("100-Rep Workout");ExerciseData.Exercise e=routine.get(Math.min(currentSet,routine.size()-1));p.addView(tv((currentSet+1)+" / "+routine.size(),13,BLUE));TextView name=tv(e.name,28,TEXT);name.setGravity(Gravity.CENTER);name.setTypeface(null,1);p.addView(name,new LinearLayout.LayoutParams(-1,70));
    int reps=setReps[Math.min(currentSet,setReps.length-1)];TextView big=tv(String.valueOf(reps),64,TEXT);big.setGravity(Gravity.CENTER);p.addView(big,new LinearLayout.LayoutParams(-1,120));p.addView(tv("REPS  •  SET "+(currentSet+1),14,MUTED));
    Button done=button("✓  SET COMPLETE",GREEN);done.setOnClickListener(v->{currentSet++;if(currentSet>=Math.min(5,routine.size()))showSummary(true);else showWorkout(false);});p.addView(done,new LinearLayout.LayoutParams(-1,60));Button finish=button("FINISH NOW",CARD2);finish.setOnClickListener(v->showSummary(true));p.addView(finish,new LinearLayout.LayoutParams(-1,54));show(p,push);
  }
  void showSummary(boolean push){LinearLayout p=page("Workout Complete");TextView ok=tv("✓",70,GREEN);ok.setGravity(Gravity.CENTER);p.addView(ok,new LinearLayout.LayoutParams(-1,110));TextView h=tv("WORKOUT COMPLETE!",26,TEXT);h.setGravity(Gravity.CENTER);h.setTypeface(null,1);p.addView(h);p.addView(tv("100 total reps\n"+routine.size()+" exercises\nSaved offline to this device",17,MUTED));Button finish=button("DONE",BLUE);finish.setOnClickListener(v->{prefs.edit().putInt("workouts",prefs.getInt("workouts",0)+1).apply();showHome(false);});p.addView(finish,new LinearLayout.LayoutParams(-1,58));show(scroll(p),push);}
  void showRoutineList(boolean push){LinearLayout p=page("My Routines");p.addView(tv("Your routines are stored locally.",14,MUTED));Button create=button("＋  CREATE NEW ROUTINE",BLUE);create.setOnClickListener(v->showRoutine(false));p.addView(create,new LinearLayout.LayoutParams(-1,58));if(prefs.getInt("workouts",0)>0)p.addView(tv("Completed workouts: "+prefs.getInt("workouts",0),18,TEXT));else p.addView(tv("No completed workouts yet",16,MUTED));show(p,push);}
  void showHistory(boolean push){LinearLayout p=page("History & Stats");int n=prefs.getInt("workouts",0);TextView stat=tv(String.valueOf(n),48,GREEN);stat.setGravity(Gravity.CENTER);p.addView(stat,new LinearLayout.LayoutParams(-1,100));p.addView(tv("100-rep workouts completed",16,MUTED));p.addView(tv("Everything is kept on this device so Reps100 remains useful without an account or connection.",14,MUTED));show(scroll(p),push);}
}
