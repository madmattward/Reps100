# Reps100 V2 upgrade

This package is a drop-in upgrade for the existing Reps100 Android project.

## Included

- Dark, polished Reps100 UI inspired by modern fitness apps.
- 340 built-in exercise entries across chest, back, shoulders, arms, legs, core, full body and cardio.
- Searchable exercise library with category filters.
- Exercise detail pages with generated photo references, muscles, equipment, movement and instructions.
- Add exercises to a routine.
- 100-rep workout runner with set progression.
- Local completion history.
- A visible back button on every secondary page.
- Android system/gesture Back support through the activity back APIs, so the phone Back button/gesture returns to the previous screen.
- No network dependency at runtime.

## Install into your Codespace

1. Upload this zip to the Codespace and unzip it.
2. From the existing Reps100 project directory, run:

   `bash /path/to/reps100_v2_package/upgrade_v2.sh`

3. Build:

   `./gradlew clean assembleRelease --no-daemon`

The script detects the existing app namespace and writes the Java source into the correct package automatically.

### Important

The three included exercise photos are original images generated for this Reps100 design. They are used as category/variation imagery in this first V2 implementation rather than downloading third-party photos, keeping the app offline-first.

Your existing release keystore is not touched by this package.
