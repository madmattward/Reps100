# Reps100

Reps100 is an offline-first Android fitness app that makes every exercise in a routine total exactly 100 reps, split across 1–10 sets with a unique rep count per set.

## Features
- Five-option main menu
- 50+ bodyweight and weight-lifting exercises
- Search by name, body part, Push/Pull and category
- Exercise diagrams and instructions
- 1–10 sets and 1–100 rep-range manager
- Random unique set splits totaling exactly 100
- Routine creation, saved library and deletion
- Guided workout flow with Next, Cancel and Finish
- Completion date/time and duration history
- Local persistence with SharedPreferences
- GitHub Actions release APK workflow

## Local build
Generate the Gradle wrapper if it is not already present:

`gradle wrapper --gradle-version 8.9 --distribution-type bin`

Then:

`./gradlew assembleRelease`

APK: `app/build/outputs/apk/release/app-release.apk`
