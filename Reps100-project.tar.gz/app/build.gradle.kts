plugins {
    id("com.android.application")
}
android {
    namespace = "com.reps100.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.reps100.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
