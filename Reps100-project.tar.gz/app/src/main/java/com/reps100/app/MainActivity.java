package com.reps100.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int GREEN=Color.rgb(27,94,32), DARK=Color.rgb(11,31,18), BG=Color.rgb(246,249,246), CARD=Color.WHITE;
    LinearLayout root, content;
    final ArrayList<Exercise> exercises = ExerciseData.all();
    final ArrayList<Routine> routines = new ArrayList<>();
    final ArrayList<Completed> completed = new ArrayList<>();
    int sets=5, minRep=10, maxRep=30;
    final Random random=new Random();
    SharedPreferences prefs;
    Routine activeRoutine; ArrayList<int[]> workoutReps; int workoutIndex=0; long workoutStart;

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("reps100",0); load(); showHome();}

    void load(){
        sets=prefs.getInt("sets",5); minRep=prefs.getInt("minRep",10); maxRep=prefs.getInt("maxRep",30);
        try{
            JSONArray a=new JSONArray(prefs.getString("routines","[]"));
            for(int i=0;i<a.length();i++) routines.add(Routine.from(a.getJSONObject(i)));
            JSONArray c=new JSONArray(prefs.getString("completed","[]"));
            for(int i=0;i<c.length();i++) completed.add(Completed.from(c.getJSONObject(i)));
        }catch(Exception ignored){}
    }
    void save(){
        JSONArray r=new JSONArray(), c=new JSONArray();
        try{for(Routine x:routines)r.put(x.toJson()); for(Completed x:completed)c.put(x.toJson());}catch(Exception ignored){}
        prefs.edit().putInt("sets",sets).putInt("minRep",minRep).putInt("maxRep",maxRep)
                .putString("routines",r.toString()).putString("completed",c.toString()).apply();
    }
    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        setContentView(root);
        TextView bar=txt(title,20,Color.WHITE); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(22,0,12,0);
        bar.setBackgroundColor(DARK); root.addView(bar,new LinearLayout.LayoutParams(-1,62));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16,14,16,20);
        ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    }
    TextView txt(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,4,0,4);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setAllCaps(false);return b;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}
    TextView heading(String s){TextView t=txt(s,22,DARK);t.setTypeface(null,1);t.setPadding(0,8,0,12);return t;}
    void backButton(){Button b=btn("← Back to main menu");b.setOnClickListener(v->showHome());content.addView(b,new LinearLayout.LayoutParams(-1,55));}

    void showHome(){
        base("Reps100");
        TextView intro=heading("100 reps. Your routine. Your record."); content.addView(intro);
        content.addView(txt("Build a routine, split every exercise into controlled sets, then track every completed workout.",15,Color.DKGRAY));
        String[] names={"Create new routine","Sets and Reps manager","Routines library","Exercise list","Record of Completed routines"};
        Runnable[] actions={this::createRoutine,this::setsManager,this::routineLibrary,this::exerciseList,this::completedList};
        for(int i=0;i<names.length;i++){Button b=btn(names[i]);b.setTextSize(17);b.setTextColor(Color.WHITE);b.setBackground(bg(GREEN,22));b.setOnClickListener(v->actions[Integer.parseInt((String)v.getTag())].run());b.setTag(""+i);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,60);lp.setMargins(0,8,0,0);content.addView(b,lp);}
        TextView f=txt("Reps100 • offline-first • data stored on this device",12,Color.GRAY);f.setGravity(Gravity.CENTER);content.addView(f,new LinearLayout.LayoutParams(-1,55));
    }

    void setsManager(){
        base("Sets & Reps manager");
        content.addView(heading("Configure your 100-rep split"));
        content.addView(txt("Choose the number of sets and the minimum/maximum reps allowed in each set. The app will generate different rep counts whose total is exactly 100.",14,Color.DKGRAY));
        Spinner ss=new Spinner(this); ArrayList<String> sv=new ArrayList<>();for(int i=1;i<=10;i++)sv.add(i+" sets");ss.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,sv));ss.setSelection(sets-1);content.addView(ss);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        EditText lo=numberField("Minimum reps",minRep), hi=numberField("Maximum reps",maxRep); row.addView(lo,new LinearLayout.LayoutParams(0,60,1));row.addView(hi,new LinearLayout.LayoutParams(0,60,1));content.addView(row);
        TextView valid=txt("",14,DARK);valid.setPadding(0,10,0,10);content.addView(valid);
        Button apply=btn("Save settings");apply.setTextColor(Color.WHITE);apply.setBackground(bg(GREEN,18));content.addView(apply);
        apply.setOnClickListener(v->{try{int n=ss.getSelectedItemPosition()+1,a=Integer.parseInt(lo.getText().toString()),z=Integer.parseInt(hi.getText().toString());
            String err=validateConfig(n,a,z);if(err!=null){valid.setText(err);return;}sets=n;minRep=a;maxRep=z;save();valid.setText("Saved. Every exercise will total exactly 100 reps.");}catch(Exception e){valid.setText("Enter whole numbers.");}});
        content.addView(txt("Tip: 5 sets with a 10–30 rep range is a flexible default.",13,Color.GRAY));backButton();
    }
    EditText numberField(String hint,int val){EditText e=new EditText(this);e.setHint(hint);e.setText(""+val);e.setInputType(2);e.setPadding(8,0,8,0);return e;}
    String validateConfig(int n,int lo,int hi){
        if(lo<1||hi>100||lo>hi)return "Rep range must be 1–100 and minimum cannot exceed maximum.";
        if(n==1 && !(lo<=100&&100<=hi))return "With 1 set, the range must include 100.";
        if(n>1 && hi-lo+1<n)return "Each set must have a different rep count, so the range needs at least "+n+" values.";
        int minSum=0,maxSum=0;for(int i=0;i<n;i++){minSum+=lo+i;maxSum+=hi-i;} if(minSum>100||maxSum<100)return "No valid unique split exists for 100 reps with those settings. Widen the range.";
        return null;
    }

    void exerciseList(){
        base("Exercise list");
        EditText search=new EditText(this);search.setHint("Search exercise, body part, push or pull");search.setSingleLine();content.addView(search,new LinearLayout.LayoutParams(-1,58));
        LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);
        String[] fs={"All","Bodyweight","Weight lifting","Push","Pull"}; for(String f:fs){Button b=btn(f);b.setTextSize(12);b.setOnClickListener(v->{for(int i=0;i<filters.getChildCount();i++)filters.getChildAt(i).setSelected(false);b.setSelected(true);refreshExercises(search.getText().toString(),f);});filters.addView(b,new LinearLayout.LayoutParams(0,48,1));}
        content.addView(filters); TextView count=txt("",12,Color.GRAY);content.addView(count);
        Runnable r=()->{String q=search.getText().toString();String f="All";for(int i=0;i<filters.getChildCount();i++)if(filters.getChildAt(i).isSelected())f=fs[i];refreshExercises(q,f);};search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){r.run();}public void afterTextChanged(android.text.Editable e){}});
        refreshExercises("", "All"); backButton();
    }
    void refreshExercises(String q,String filter){
        while(content.getChildCount()>2)content.removeViewAt(2); // keep search + filters
        q=q.toLowerCase(Locale.US);int shown=0;
        for(Exercise e:exercises){
            boolean match=q.isEmpty()||(e.name+" "+e.body+" "+e.type+" "+e.action+" "+e.description).toLowerCase(Locale.US).contains(q);
            boolean f=filter.equals("All")||(filter.equals("Bodyweight")&&e.type.equals("Bodyweight"))||(filter.equals("Weight lifting")&&e.type.equals("Weight lifting"))||(filter.equals("Push")&&e.action.equals("Push"))||(filter.equals("Pull")&&e.action.equals("Pull"));
            if(match&&f){shown++;addExerciseCard(content,e,false);}
        }
        // count is removed by list clearing; add it back after filters
        TextView c=txt(shown+" exercise"+(shown==1?"":"s"),12,Color.GRAY);content.addView(c,2);
    }
    void addExerciseCard(LinearLayout box,Exercise e,boolean pick){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setPadding(10,8,10,8);card.setBackground(bg(CARD,18));
        ExerciseDiagramView d=new ExerciseDiagramView(this,e.pattern);card.addView(d,new LinearLayout.LayoutParams(135,105));
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);info.setPadding(10,0,0,0);
        TextView n=txt(e.name,16,DARK);n.setTypeface(null,1);info.addView(n);info.addView(txt(e.type+" • "+e.body+" • "+e.action,12,GREEN));info.addView(txt(e.description,13,Color.DKGRAY));
        if(pick){Button b=btn("Add");b.setOnClickListener(v->{selectedForRoutine.add(e.name);Toast.makeText(this,e.name+" added",Toast.LENGTH_SHORT).show();});info.addView(b);}
        card.addView(info,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,0);box.addView(card,lp);
    }
    final ArrayList<String> selectedForRoutine=new ArrayList<>();

    void createRoutine(){
        selectedForRoutine.clear();base("Create new routine");content.addView(heading("Build your routine"));
        EditText name=new EditText(this);name.setHint("Routine name");content.addView(name,new LinearLayout.LayoutParams(-1,58));
        TextView chosen=txt("No exercises selected.",14,DARK);content.addView(chosen);
        Button add=btn("+ Add exercises");content.addView(add);add.setOnClickListener(v->exercisePicker(chosen));
        Button saveB=btn("Save routine");saveB.setTextColor(Color.WHITE);saveB.setBackground(bg(GREEN,18));content.addView(saveB);
        saveB.setOnClickListener(v->{String nm=name.getText().toString().trim();if(nm.isEmpty()){name.setError("Enter a name");return;}if(selectedForRoutine.isEmpty()){Toast.makeText(this,"Add at least one exercise.",Toast.LENGTH_SHORT).show();return;}routines.add(new Routine(nm,new ArrayList<>(selectedForRoutine)));save();showRoutineDetail(routines.get(routines.size()-1));});
        backButton();
    }
    void exercisePicker(TextView chosen){
        final Dialog dialog=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(14,14,14,14);
        TextView h=heading("Select exercises");box.addView(h);EditText s=new EditText(this);s.setHint("Search");box.addView(s);
        ScrollView sc=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);box.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        Button done=btn("Done");box.addView(done);done.setOnClickListener(v->{chosen.setText("Selected: "+String.join(", ",selectedForRoutine));dialog.dismiss();});
        dialog.setContentView(box);Window w=dialog.getWindow();if(w!=null)w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94),-1);dialog.show();if(dialog.getWindow()!=null)dialog.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94),(int)(getResources().getDisplayMetrics().heightPixels*.85));
        Runnable fill=()->{list.removeAllViews();String q=s.getText().toString().toLowerCase(Locale.US);for(Exercise e:exercises)if(q.isEmpty()||e.name.toLowerCase(Locale.US).contains(q)||e.body.toLowerCase(Locale.US).contains(q))addExerciseCard(list,e,true);};s.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){fill.run();}public void afterTextChanged(android.text.Editable e){}});fill.run();
    }

    void routineLibrary(){
        base("Routines library");content.addView(heading("Saved routines"));
        if(routines.isEmpty())content.addView(txt("No routines yet. Create one from the main menu.",15,Color.DKGRAY));
        for(Routine r:routines){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(12,8,12,8);c.setBackground(bg(CARD,18));TextView n=txt(r.name,18,DARK);n.setTypeface(null,1);c.addView(n);c.addView(txt(r.exercises.size()+" exercises • "+sets+" sets each • 100 reps each",13,Color.DKGRAY));
            LinearLayout row=new LinearLayout(this);Button start=btn("Start");Button del=btn("Delete");row.addView(start,new LinearLayout.LayoutParams(0,55,1));row.addView(del,new LinearLayout.LayoutParams(0,55,1));c.addView(row);start.setOnClickListener(v->startRoutine(r));del.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("Delete routine?").setMessage(r.name).setNegativeButton("No",null).setPositiveButton("Delete",(d,w)->{routines.remove(r);save();routineLibrary();}).show();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,0);content.addView(c,lp);}
        backButton();
    }
    void showRoutineDetail(Routine r){routineLibrary();}

    void startRoutine(Routine r){
        String err=validateConfig(sets,minRep,maxRep);if(err!=null){new AlertDialog.Builder(this).setTitle("Settings cannot generate 100 reps").setMessage(err).setPositiveButton("Open manager",(d,w)->setsManager()).setNegativeButton("Cancel",null).show();return;}
        activeRoutine=r;workoutStart=System.currentTimeMillis();workoutIndex=0;workoutReps=new ArrayList<>();
        for(int i=0;i<r.exercises.size();i++)workoutReps.add(generateSplit(sets,minRep,maxRep));
        showWorkout();
    }
    int[] generateSplit(int n,int lo,int hi){
        for(int tries=0;tries<10000;tries++){ArrayList<Integer> vals=new ArrayList<>();for(int x=lo;x<=hi;x++)vals.add(x);Collections.shuffle(vals,random);int[] out=new int[n];if(searchSplit(vals,0,n,100,new HashSet<Integer>(),out))return out;}
        throw new IllegalStateException("No split");
    }
    boolean searchSplit(ArrayList<Integer> vals,int start,int n,int target,Set<Integer> used,int[] out){
        if(n==0)return target==0;
        if(target<=0)return false;
        for(int i=start;i<vals.size();i++){int v=vals.get(i);if(v>target)continue;out[out.length-n]=v;used.add(v);if(searchSplit(vals,i+1,n-1,target-v,used,out))return true;used.remove(v);}
        return false;
    }
    void showWorkout(){
        base("Reps100 • "+activeRoutine.name);
        int ex=workoutIndex%activeRoutine.exercises.size(), set=workoutIndex/activeRoutine.exercises.size();
        Exercise e=findExercise(activeRoutine.exercises.get(ex));int reps=workoutReps.get(ex)[set];boolean last=workoutIndex==(activeRoutine.exercises.size()*sets-1);
        content.addView(txt("Set "+(set+1)+" of "+sets+" • Exercise "+(ex+1)+" of "+activeRoutine.exercises.size(),14,GREEN));
        TextView title=heading(e.name);content.addView(title);
        ExerciseDiagramView diagram=new ExerciseDiagramView(this,e.pattern);content.addView(diagram,new LinearLayout.LayoutParams(-1,220));
        content.addView(txt("Do "+reps+" reps",26,DARK));content.addView(txt(e.description,16,Color.DKGRAY));
        TextView total=txt("100-rep target • This exercise: "+sum(workoutReps.get(ex))+" reps scheduled",13,Color.GRAY);content.addView(total);
        LinearLayout row=new LinearLayout(this);
        Button action=btn(last?"Finish":"Next");action.setTextColor(Color.WHITE);action.setBackground(bg(GREEN,18));row.addView(action,new LinearLayout.LayoutParams(0,60,1));
        if(!last){Button cancel=btn("Cancel");row.addView(cancel,new LinearLayout.LayoutParams(0,60,1));cancel.setOnClickListener(v->showHome());}
        content.addView(row);action.setOnClickListener(v->{if(last)finishWorkout();else{workoutIndex++;showWorkout();}});
    }
    int sum(int[] a){int s=0;for(int x:a)s+=x;return s;}
    Exercise findExercise(String n){for(Exercise e:exercises)if(e.name.equals(n))return e;return exercises.get(0);}
    void finishWorkout(){long dur=System.currentTimeMillis()-workoutStart;completed.add(new Completed(activeRoutine.name,System.currentTimeMillis(),dur));save();new AlertDialog.Builder(this).setTitle("Routine complete!").setMessage(activeRoutine.name+" recorded. Duration: "+formatDuration(dur)).setPositiveButton("Main menu",(d,w)->showHome()).setCancelable(false).show();}
    String formatDuration(long ms){long s=ms/1000;long h=s/3600;s%=3600;long m=s/60;s%=60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}

    void completedList(){
        base("Completed routines");content.addView(heading("Completion history"));
        if(completed.isEmpty())content.addView(txt("No completed routines yet.",15,Color.DKGRAY));
        SimpleDateFormat f=new SimpleDateFormat("EEE, d MMM yyyy • HH:mm",Locale.getDefault());
        for(Completed c:completed){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(12,10,12,10);card.setBackground(bg(CARD,18));TextView n=txt(c.name,17,DARK);n.setTypeface(null,1);card.addView(n);card.addView(txt(f.format(new Date(c.when)),14,Color.DKGRAY));card.addView(txt("Duration: "+formatDuration(c.duration),14,GREEN));Button del=btn("Delete record");card.addView(del);del.setOnClickListener(v->{completed.remove(c);save();completedList();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,0);content.addView(card,lp);}
        backButton();
    }

    static class Routine{String name;ArrayList<String> exercises;Routine(String n,ArrayList<String> e){name=n;exercises=e;}JSONObject toJson()throws Exception{JSONObject o=new JSONObject();o.put("name",name);JSONArray a=new JSONArray();for(String s:exercises)a.put(s);o.put("exercises",a);return o;}static Routine from(JSONObject o)throws Exception{ArrayList<String>a=new ArrayList<>();JSONArray j=o.getJSONArray("exercises");for(int i=0;i<j.length();i++)a.add(j.getString(i));return new Routine(o.getString("name"),a);}}
    static class Completed{String name;long when,duration;Completed(String n,long w,long d){name=n;when=w;duration=d;}JSONObject toJson()throws Exception{return new JSONObject().put("name",name).put("when",when).put("duration",duration);}static Completed from(JSONObject o)throws Exception{return new Completed(o.getString("name"),o.getLong("when"),o.getLong("duration"));}}
    static class Exercise{String name,type,body,action,description,pattern;Exercise(String n,String t,String b,String a,String d,String p){name=n;type=t;body=b;action=a;description=d;pattern=p;}}

    public static class ExerciseDiagramView extends View{
        Paint p=new Paint(1);String pattern;ExerciseDiagramView(Context c,String pat){super(c);pattern=pat;p.setStrokeWidth(7);p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);}
        protected void onDraw(Canvas c){super.onDraw(c);p.setColor(Color.rgb(40,65,48));float w=getWidth(),h=getHeight(),cx=w/2f; c.drawColor(Color.rgb(235,242,235));
            float headY=h*.25f, bodyY=h*.48f;
            c.drawCircle(cx,headY,18,p); 
            if(pattern.equals("push")||pattern.equals("plank")){line(c,cx-55,h*.62f,cx+45,h*.48f);line(c,cx-20,h*.55f,cx-55,h*.70f);line(c,cx+25,h*.52f,cx+65,h*.68f);line(c,cx+45,h*.48f,cx+72,h*.66f);}
            else if(pattern.equals("squat")||pattern.equals("lunge")){line(c,cx,headY+18,cx-10,h*.48f);line(c,cx-10,h*.48f,cx-50,h*.68f);line(c,cx-10,h*.48f,cx+45,h*.62f);line(c,cx-50,h*.68f,cx-70,h*.85f);line(c,cx+45,h*.62f,cx+70,h*.82f);line(c,cx-10,h*.32f,cx-45,h*.45f);line(c,cx-10,h*.32f,cx+38,h*.42f);}
            else if(pattern.equals("pullup")||pattern.equals("latpull")||pattern.equals("row")){line(c,cx-70,h*.12f,cx+70,h*.12f);line(c,cx,headY+18,cx,h*.52f);line(c,cx,h*.52f,cx-35,h*.82f);line(c,cx,h*.52f,cx+35,h*.82f);line(c,cx-2,h*.35f,cx-45,h*.20f);line(c,cx+2,h*.35f,cx+45,h*.20f);}
            else if(pattern.equals("curl")||pattern.equals("press")){line(c,cx,headY+18,cx,h*.58f);line(c,cx,h*.58f,cx-32,h*.85f);line(c,cx,h*.58f,cx+32,h*.85f);line(c,cx-2,h*.38f,cx-50,h*.22f);line(c,cx+2,h*.38f,cx+50,h*.22f); if(pattern.equals("press")){line(c,cx-50,h*.22f,cx-50,h*.08f);line(c,cx+50,h*.22f,cx+50,h*.08f);}}
            else {line(c,cx,headY+18,cx,h*.55f);line(c,cx,h*.55f,cx-32,h*.84f);line(c,cx,h*.55f,cx+32,h*.84f);line(c,cx-2,h*.38f,cx-50,h*.48f);line(c,cx+2,h*.38f,cx+50,h*.48f);}
        }
        void line(Canvas c,float a,float b,float d,float e){c.drawLine(a,b,d,e,p);}
    }

    static class ExerciseData{
        static ArrayList<Exercise> all(){ArrayList<Exercise>x=new ArrayList<>();
            add(x,"Push-up","Bodyweight","Chest","Push","Start in a high plank. Lower your chest with elbows controlled, then press the floor away to full arm extension.","push");
            add(x,"Incline Push-up","Bodyweight","Chest","Push","Place hands on a sturdy raised surface. Keep your body straight, lower your chest, and press back up.","push");
            add(x,"Diamond Push-up","Bodyweight","Triceps","Push","Make a diamond with your hands beneath the chest. Lower under control and press up without flaring the elbows.","push");
            add(x,"Pike Push-up","Bodyweight","Shoulders","Push","From a pike position with hips high, bend the elbows and lower the head toward the floor, then press away.","push");
            add(x,"Archer Push-up","Bodyweight","Chest","Push","Use a wide hand position. Bend one elbow while the other arm stays straighter, then push back to center.","push");
            add(x,"Bodyweight Squat","Bodyweight","Quads","Push","Stand with feet about shoulder width. Sit the hips back and down, then drive through the feet to stand.","squat");
            add(x,"Split Squat","Bodyweight","Quads","Push","Take a staggered stance. Lower the back knee toward the floor while keeping the front foot planted, then rise.","lunge");
            add(x,"Reverse Lunge","Bodyweight","Glutes","Push","Step one foot back, lower both knees, then drive through the front foot to return to standing.","lunge");
            add(x,"Walking Lunge","Bodyweight","Glutes","Push","Step forward into a lunge, lower under control, then bring the rear leg forward and repeat.","lunge");
            add(x,"Bulgarian Split Squat","Bodyweight","Quads","Push","Place the rear foot on a stable bench. Lower the hips with the front knee tracking over the foot, then stand.","lunge");
            add(x,"Glute Bridge","Bodyweight","Glutes","Push","Lie on your back with knees bent. Brace your core and squeeze the glutes to lift the hips, then lower slowly.","squat");
            add(x,"Single-leg Glute Bridge","Bodyweight","Glutes","Push","Keep one foot planted and the other leg extended. Lift the hips by squeezing the planted-side glute.","squat");
            add(x,"Calf Raise","Bodyweight","Calves","Push","Stand tall and rise onto the balls of your feet. Pause at the top, then lower your heels slowly.","squat");
            add(x,"Single-leg Calf Raise","Bodyweight","Calves","Push","Balance on one foot, rise through the ball of the foot, pause, and lower with control.","squat");
            add(x,"Wall Sit","Bodyweight","Quads","Push","Slide your back down a wall until thighs are roughly parallel to the floor. Brace and hold the position.","squat");
            add(x,"Step-up","Bodyweight","Glutes","Push","Place one foot on a stable step, drive through that foot to stand on the step, then lower under control.","lunge");
            add(x,"Burpee","Bodyweight","Full body","Push","Squat down, place hands down, step or jump to plank, return to squat, then stand tall with control.","push");
            add(x,"Mountain Climber","Bodyweight","Core","Push","Start in plank. Drive one knee toward the chest, return it, and alternate while keeping hips stable.","plank");
            add(x,"Plank","Bodyweight","Core","Push","Support yourself on forearms or hands with a straight line from head to heels. Brace the abdomen and breathe.","plank");
            add(x,"Side Plank","Bodyweight","Core","Push","Support the body on one forearm and the side of one foot. Keep hips lifted and your body in a straight line.","plank");
            add(x,"Dead Bug","Bodyweight","Core","Push","Lie on your back with hips and knees bent. Brace the abdomen and slowly extend opposite arm and leg.","plank");
            add(x,"Bicycle Crunch","Bodyweight","Core","Push","Lie on your back, brace the core, and rotate one shoulder toward the opposite knee while alternating sides.","plank");
            add(x,"Hanging Knee Raise","Bodyweight","Core","Pull","Hang securely from a bar. Curl the pelvis and raise the knees without swinging, then lower slowly.","pullup");
            add(x,"Pull-up","Bodyweight","Back","Pull","Grip a bar overhand. Pull the chest toward the bar while keeping the body controlled, then lower fully.","pullup");
            add(x,"Chin-up","Bodyweight","Back","Pull","Use an underhand grip. Pull the chest toward the bar, squeeze the back and arms, then lower under control.","pullup");
            add(x,"Inverted Row","Bodyweight","Back","Pull","Hang beneath a secure low bar or table edge. Pull the chest toward the support while keeping the body straight.","row");
            add(x,"Band Row","Bodyweight","Back","Pull","Anchor a resistance band securely. Pull the handles toward the ribs while squeezing the shoulder blades.","row");
            add(x,"Bodyweight Hip Hinge","Bodyweight","Hamstrings","Pull","Stand tall, soften the knees, push the hips back with a neutral spine, then squeeze the glutes to stand.","row");
            add(x,"Dumbbell Bench Press","Weight lifting","Chest","Push","Lie on a bench with dumbbells over the chest. Lower with elbows controlled, then press back up.","press");
            add(x,"Barbell Bench Press","Weight lifting","Chest","Push","Set the bar over the chest with a stable upper back. Lower to the chest with control and press vertically.","press");
            add(x,"Dumbbell Shoulder Press","Weight lifting","Shoulders","Push","Press dumbbells from shoulder level overhead while keeping the ribs controlled. Lower to shoulder height.","press");
            add(x,"Barbell Overhead Press","Weight lifting","Shoulders","Push","Start the bar at upper chest level. Brace the body and press straight overhead, then lower under control.","press");
            add(x,"Dumbbell Lateral Raise","Weight lifting","Shoulders","Push","With soft elbows, raise dumbbells out to shoulder height without swinging, then lower slowly.","press");
            add(x,"Dumbbell Goblet Squat","Weight lifting","Quads","Push","Hold one dumbbell at the chest. Squat between the hips while keeping the torso braced, then stand.","squat");
            add(x,"Barbell Back Squat","Weight lifting","Quads","Push","Place the bar securely across the upper back. Brace, squat with controlled depth, and drive up through the feet.","squat");
            add(x,"Barbell Front Squat","Weight lifting","Quads","Push","Rest the bar on the front shoulders with a strong rack. Squat upright, then drive through the floor to stand.","squat");
            add(x,"Dumbbell Bulgarian Split Squat","Weight lifting","Quads","Push","Hold dumbbells at your sides and place the rear foot on a bench. Lower and rise through the front leg.","lunge");
            add(x,"Dumbbell Romanian Deadlift","Weight lifting","Hamstrings","Pull","Hold dumbbells close to the thighs. Push hips back with a neutral spine, feel the hamstrings load, then stand.","row");
            add(x,"Barbell Romanian Deadlift","Weight lifting","Hamstrings","Pull","Hold the bar close, hinge at the hips with a neutral spine, then squeeze glutes to return upright.","row");
            add(x,"Conventional Deadlift","Weight lifting","Back","Pull","Set the bar over mid-foot. Brace, push the floor away, keep the bar close, and stand tall without leaning back.","row");
            add(x,"Dumbbell Bent-over Row","Weight lifting","Back","Pull","Hinge with a neutral spine. Pull the dumbbells toward the ribs, squeeze the back, and lower with control.","row");
            add(x,"Barbell Bent-over Row","Weight lifting","Back","Pull","Hinge at the hips and pull the bar toward the lower ribs while keeping the torso stable.","row");
            add(x,"Seated Cable Row","Weight lifting","Back","Pull","Sit tall with a braced torso. Pull the handle toward the lower ribs, squeeze the shoulder blades, and return slowly.","row");
            add(x,"Lat Pulldown","Weight lifting","Back","Pull","Grip the bar wider than shoulder width. Pull it toward the upper chest without leaning excessively, then control the return.","latpull");
            add(x,"Face Pull","Weight lifting","Shoulders","Pull","Set a cable or band around face height. Pull toward the face with elbows high and rotate the hands outward.","row");
            add(x,"Dumbbell Biceps Curl","Weight lifting","Biceps","Pull","Keep elbows near your sides. Curl the dumbbells without swinging, squeeze at the top, and lower slowly.","curl");
            add(x,"Hammer Curl","Weight lifting","Biceps","Pull","Use a neutral grip with palms facing inward. Curl while keeping elbows close, then lower under control.","curl");
            add(x,"EZ-bar Curl","Weight lifting","Biceps","Pull","Grip the EZ-bar comfortably. Curl toward the shoulders without moving the upper arms, then lower slowly.","curl");
            add(x,"Cable Triceps Pushdown","Weight lifting","Triceps","Push","Keep elbows close to the torso. Push the handle down until arms extend, then return without letting elbows drift.","press");
            add(x,"Dumbbell Triceps Extension","Weight lifting","Triceps","Push","Hold a dumbbell overhead. Bend the elbows to lower it behind the head, then extend the elbows smoothly.","press");
            add(x,"Skull Crusher","Weight lifting","Triceps","Push","Lie on a bench with weights above the chest. Bend the elbows to lower toward the forehead, then extend carefully.","press");
            add(x,"Dumbbell Pullover","Weight lifting","Chest","Pull","Lie on a bench holding one dumbbell above the chest. Lower it behind the head with controlled shoulders, then return.","pullup");
            add(x,"Dumbbell Shrug","Weight lifting","Traps","Pull","Hold weights at the sides. Lift the shoulders straight up without rolling them, pause, and lower.","row");
            add(x,"Barbell Hip Thrust","Weight lifting","Glutes","Push","Rest the upper back on a bench with the bar across the hips. Drive hips upward by squeezing the glutes.","squat");
            add(x,"Cable Wood Chop","Weight lifting","Core","Pull","Set a cable high or low. Rotate the torso under control while bracing the core, then return to the start.","row");
            add(x,"Weighted Crunch","Weight lifting","Core","Push","Hold a light weight at the chest. Curl the upper torso toward the pelvis while keeping the lower back controlled.","plank");
            add(x,"Farmer Carry","Weight lifting","Grip","Pull","Carry weights at your sides with tall posture, braced core, and steady steps. Avoid leaning or shrugging.","row");
            return x;}
        static void add(ArrayList<Exercise>x,String n,String t,String b,String a,String d,String p){x.add(new Exercise(n,t,b,a,d,p));}
    }
}
