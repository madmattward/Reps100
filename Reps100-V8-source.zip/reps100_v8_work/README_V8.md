# Reps100 V8

V8 changes include:
- launcher icon based on the supplied blue REPS 100 barbell artwork
- updated BMI male/female visual scales with clearly different body-size categories
- clearer waist-to-hip ratio reference table
- corrected measurement overlay: height top-of-head to bottom-of-feet, waist/hip guides confined to torso/hip body edges
- keyboard-aware Create Routine weight entry with scroll restoration
- updated Sets & Reps Manager wording
- completed-routine calendar days use the same calorie tier colour as the bar chart
- bench press now uses distinct extended/start and lowered/midpoint imagery
- versionCode 7 / versionName 8.0

The project remains offline-first. Calorie, BMI and ratio results are estimates/screening indicators, not medical diagnoses.
